# static_adhesion > 2022-08-22 6:18pm
https://universe.roboflow.com/mustafa-sevim/static_adhesion

Provided by a Roboflow user
License: CC BY 4.0

